"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const promise_1 = __importDefault(require("mysql2/promise"));
const tmp_1 = __importDefault(require("tmp"));
const fs_1 = __importDefault(require("fs"));
async function jobArrived(s, flowElement, job) {
    let varHost = await flowElement.getPropertyStringValue("host");
    let varUser = await flowElement.getPropertyStringValue("user");
    let varPassword = await flowElement.getPropertyStringValue("password");
    let varDB = await flowElement.getPropertyStringValue("database");
    let varQuery = await flowElement.getPropertyStringValue("query");
    const connection = await promise_1.default.createConnection({
        host: varHost,
        user: varUser,
        password: varPassword,
        database: varDB,
    });
    try {
        const [outputQuery] = await connection.query(varQuery[0]);
        console.log(outputQuery);
        const tmpDataset = tmp_1.default.fileSync({ prefix: 'JSON', postfix: '.json' }).name;
        fs_1.default.writeFileSync(tmpDataset, JSON.stringify(outputQuery));
        await job.createDataset('DB_JSON', tmpDataset, DatasetModel.JSON);
        await job.sendToData(Connection.Level.Success);
        fs_1.default.unlinkSync(tmpDataset);
    }
    catch (err) {
        console.log(err);
        await job.sendToData(Connection.Level.Error);
    }
    //connection.release();
}
//# sourceMappingURL=main.js.map