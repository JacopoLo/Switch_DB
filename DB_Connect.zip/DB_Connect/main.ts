import mysql from 'mysql2/promise';
import tmp from 'tmp';
import fs from 'fs';
import { XMLParser, XMLBuilder, XMLValidator } from "fast-xml-parser";

async function jobArrived(s: Switch, flowElement: FlowElement, job: Job) {

    
    let varHost = await flowElement.getPropertyStringValue("host") as string;
    let varUser = await flowElement.getPropertyStringValue("user") as string;
    let varPassword = await flowElement.getPropertyStringValue("password") as string;
    let varDB = await flowElement.getPropertyStringValue("database") as string;

    let varQuery = await flowElement.getPropertyStringValue("query") as string;
    
    
    const connection = await mysql.createConnection({
        host: varHost,
        user: varUser,
        password: varPassword,
        database: varDB,
    });

    try {
        const [outputQuery] = await connection.query(varQuery[0]);

        console.log(outputQuery);

        const tmpDataset: string = tmp.fileSync({prefix: 'JSON', postfix: '.json'}).name;
        fs.writeFileSync(tmpDataset, JSON.stringify(outputQuery));

        await job.createDataset('DB_JSON',tmpDataset,DatasetModel.JSON);
        await job.sendToData(Connection.Level.Success);

        fs.unlinkSync(tmpDataset);

    }catch (err) {
        console.log(err);
        await job.sendToData(Connection.Level.Error);
    }
    //connection.release();



}
